<!DOCTYPE html>
<html>
<head>
       <title>Simple CRUD</title>
</head>
<body>
<h1>Simple CRUD</h1>
<a href="insert.php">Insert</a>
<a href="view.php">View</a>
</body>
</html>