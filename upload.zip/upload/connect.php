<?php
$connection = new mysqli("localhost","root","","crudphp");
if(!$connection){
        echo "Connection error!";
        exit();
    }