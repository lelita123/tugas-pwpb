
package Perkenalan;


public class variabel {
    public static void main(String[]args){
        byte nilai_byte = 70;
        short nilai_short = 500;
        int nilai_int = 263456;
        long nilai_long = 1200000;
        char nilai_char = 'A';
        float nilai_float = 190;
        double nilai_double = 387;
        boolean nilai_boolean = true;
        
        System.out.println("nilai byte= "+nilai_byte);
        System.out.println("nilai short= "+nilai_short);
        System.out.println("nilai int= "+nilai_int);
        System.out.println("nilai long= "+nilai_long);
        System.out.println("nilai char= "+nilai_char);
        System.out.println("nilai float= "+nilai_float); 
        System.out.println("nilai double= "+nilai_double);
        System.out.println("nilai boolean= "+nilai_boolean);
        
    }
            
}
