
package Perkenalan;

import java.util.Scanner;

;
public class HELLO {
    public static void main(String [] haiiii){
        System.out.println("Hello World...");
      Scanner input=new Scanner(System.in);
      
      System.out.println("Masukkan nama anda");
        System.out.println("Nama : ");
        String nama=input.nextLine();
        System.out.println("Alamat :");
        String alamat=input.nextLine();
        System.out.println("Usia : ");
        String usia=input.nextLine();
        
    }
           
}
