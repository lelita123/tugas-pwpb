
package Perkenalan;


public class Akoehhhhhh {
    public static void main(String[]args){
        int i =10;
        int j = 3;
        int k = 0;
        k = ++j + i;
        
   int ii = 10;
   int jj = 3;
   int kk = 0;
   kk = jj++ + i;
        System.out.println(k);
        System.out.println(kk);
           
                
        
        
    }
}
