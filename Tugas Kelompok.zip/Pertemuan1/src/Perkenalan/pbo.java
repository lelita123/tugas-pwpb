
package Perkenalan;

import java.util.Scanner;
public class pbo {
   public static void main(String[]args){
       int nilai = 60;
               if(nilai>75);
               System.out.println("Lulus");
   }           
    if else}
            System.out.println("gagal");
    
}
}
   
